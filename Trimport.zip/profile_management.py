
import os
import json
import importlib.util

def load_manipulations():
    manipulations = {}
    directory = os.path.join(os.path.dirname(__file__), '../data_manipulation')
    for filename in os.listdir(directory):
        if filename.endswith('.py') and filename != 'manipulation_core.py':
            module_name = filename[:-3]
            file_path = os.path.join(directory, filename)
            spec = importlib.util.spec_from_file_location(module_name, file_path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            # Ensure that we are loading metadata, not functions
            if hasattr(module, 'metadata'):
                manipulations[module_name] = module.metadata
                print(f'Loaded metadata for {module_name}:', module.metadata)
            else:
                print(f'No metadata found for {module_name}, loaded item is a function')
    return manipulations
def get_profiles():
    profiles_file = 'trim_profiles.json'
    if os.path.exists(profiles_file):
        with open(profiles_file, 'r') as file:
            profiles = json.load(file)
    else:
        profiles = {}
    return profiles

def save_profiles(profiles):
    with open('trim_profiles.json', 'w') as file:
        json.dump(profiles, file, indent=4)

def create_profile(manipulation_options):
    new_profile = {}
    for option, metadata in manipulation_options.items():
        response = input(metadata['query'])
        if response.strip():  # Ensure the response is not empty
            if metadata['type'] == 'boolean':
                new_profile[option] = response.lower() == 'y'
            elif metadata['type'] == 'list':
                new_profile[option] = response.split(',')
            elif metadata['type'] == 'integer':
                try:
                    new_profile[option] = int(response)
                except ValueError:
                    print(f"Invalid input for {option}. Please enter a valid integer.")
                    continue  # Optionally, you could loop until valid input is received
            elif metadata['type'] == 'string':
                new_profile[option] = response
        else:
            print(f"No input provided for {option}. Skipping this setting.")
    return new_profile