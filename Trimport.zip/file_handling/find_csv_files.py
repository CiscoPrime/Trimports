
import os

def find_csv_files(directory):
    """List all CSV files in the specified directory."""
    return [f for f in os.listdir(directory) if f.endswith('.csv')]
