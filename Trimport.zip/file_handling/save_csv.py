
import pandas as pd

def save_csv(df, file_path, index=False):
    """Save DataFrame to a CSV file."""
    df.to_csv(file_path, index=index)
