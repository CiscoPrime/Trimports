
import pandas as pd

def load_csv(file_name):
    """Load CSV file and return a DataFrame, correctly handling the header."""
    return pd.read_csv(file_name)
