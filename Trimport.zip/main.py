
import os
from file_handling.find_csv_files import find_csv_files
from file_handling.load_csv import load_csv
from file_handling.save_csv import save_csv
from profile_management import get_profiles, save_profiles, create_profile
from data_manipulation.manipulation_core import load_manipulations

def main():
    current_directory = os.getcwd()
    csv_files = find_csv_files(current_directory)
    if not csv_files:
        print("No CSV files found in the directory.")
        return

    print("Available CSV files:")
    for index, file in enumerate(csv_files, 1):
        print(f"{index}. {file}")
    file_choice = int(input("Select a CSV file to trim (number): ")) - 1
    file_name = os.path.join(current_directory, csv_files[file_choice])

    df = load_csv(file_name)
    df_trimmed = df.copy()  # Initialize df_trimmed to ensure it exists even if not modified
    print("Original Data (first row treated as data):")
    print(df.head())

    profiles = get_profiles()
    manipulation_options = load_manipulations()
    if not profiles:
        print("No profiles found, creating a new one.")
        profiles['Profile1'] = create_profile(manipulation_options)
        save_profiles(profiles)

    print("Select a trimming profile:")
    for i, key in enumerate(profiles.keys(), 1):
        print(f"{i}. {key}")
    print(f"{len(profiles) + 1}. Create a new trimming profile")

    choice = int(input("Enter your choice: "))
    if choice == len(profiles) + 1:
        profile_name = f"Profile{len(profiles) + 1}"
        profiles[profile_name] = create_profile(manipulation_options)
        save_profiles(profiles)
    else:
        profile_name = list(profiles.keys())[choice - 1]

    def apply_profile(df, profile, manipulation_options):
        for key, value in profile.items():
            if value and key in manipulation_options:
                manipulation_function = manipulation_options[key]['function']
                df = manipulation_function(df, value)
        return df

    if input("Save changes to new CSV file? (y/n): ") == 'y':
        if profiles[profile_name].get("use_first_row_as_header"):
            header = df_trimmed.iloc[0]
            df_trimmed = df_trimmed[1:]
            df_trimmed.to_csv(f'trimmed_{os.path.basename(file_name)}', index=False, header=header)
        else:
            df_trimmed.to_csv(f'trimmed_{os.path.basename(file_name)}', index=False, header=False)
        print("Changes saved.")

if __name__ == "__main__":
    main()
