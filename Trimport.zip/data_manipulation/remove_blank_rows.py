import pandas as pd

metadata = {'query': 'Remove blank rows? (y/n): ', 'type': 'boolean'}

def manipulation(df, activate):
    if activate:
        return df.dropna(how='all')
    return df
