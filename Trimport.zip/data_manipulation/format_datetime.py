import pandas as pd

metadata = {'query': 'Format a column as datetime? Enter column index: ', 'type': 'integer'}

def manipulation(df, column_index):
    datetime_col = int(column_index) - 1  # convert to zero-based index
    df.iloc[:, datetime_col] = pd.to_datetime(df.iloc[:, datetime_col])
    return df
