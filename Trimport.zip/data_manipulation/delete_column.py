import pandas as pd

metadata = {'query': 'Delete a specific column by name or index? (Enter column identifier): ', 'type': 'string'}

def manipulation(df, column):
    try:
        col_index = int(column) - 1  # Assuming one-based index from user
        if col_index < len(df.columns):
            return df.drop(df.columns[col_index], axis=1)
    except ValueError:
        if column in df.columns:
            return df.drop(columns=[column])
    return df
