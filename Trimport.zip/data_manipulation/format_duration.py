import pandas as pd
import re

# Metadata for integration with the system, instructing users how to skip
metadata = {
    'query': 'Format which column as custom time duration? (Enter column index or type "skip" to omit): ',
    'type': 'string'  # Changed to string to handle the 'skip' input
}

def manipulation(df, column_index):
    # Check if the user wants to skip this manipulation
    if column_index.lower() == 'skip':
        return df  # Return the DataFrame unchanged
    
    # Attempt to convert the column index to an integer and apply the parsing
    try:
        column_index = int(column_index)
        if 0 <= column_index < len(df.columns):
            # Function to parse custom time format
            def parse_custom_time(time_str):
                match = re.match(r'(?:(?P<years>\d+)\s*yrs?)?\s*(?:(?P<months>\d+)\s*mon?)?\s*(?:(?P<days>\d+)\s*day?)?\s*(?:(?P<hours>\d+)\s*hrs?)?\s*(?:(?P<minutes>\d+)\s*min)?\s*(?:(?P<seconds>\d+)\s*sec)?', time_str)
                if match:
                    years = int(match.group('years') or 0)
                    months = int(match.group('months') or 0)
                    days = int(match.group('days') or 0)
                    hours = int(match.group('hours') or 0)
                    minutes = int(match.group('minutes') or 0)
                    seconds = int(match.group('seconds') or 0)
                    timestamp = f"{days:02d}/{months:02d}/{years:04d} {hours:02d}:{minutes:02d}:{seconds:02d}"
                    print(f"Match found: Converting '{time_str}' to '{timestamp}'")
                    return timestamp
                else:
                    print(f"No match found for '{time_str}'")
                    return pd.NaT  # Return NaT for non-matching values
            df.iloc[:, column_index] = df.iloc[:, column_index].apply(parse_custom_time)
    except ValueError:
        print("Invalid column index provided. No changes made.")
    
    return df