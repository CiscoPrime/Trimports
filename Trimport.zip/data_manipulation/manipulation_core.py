
import os
import importlib.util

def load_manipulations():
    manipulations = {}
    directory = os.path.join(os.path.dirname(__file__))
    for filename in os.listdir(directory):
        if filename.endswith('.py') and filename != 'manipulation_core.py':
            module_name = filename[:-3]
            file_path = os.path.join(directory, filename)
            spec = importlib.util.spec_from_file_location(module_name, file_path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            # Ensure the module contains metadata and is not the core or other utility modules
            if hasattr(module, 'metadata') and isinstance(module.metadata, dict):
                manipulations[module_name] = module.metadata
            else:
                print(f"No valid metadata in {module_name}. It may be the core or an incorrectly setup module.")
    return manipulations

def apply_manipulation(df, profile, manipulation_options):
    for option, func in manipulation_options.items():
        if option in profile:
            df = func(df, profile[option])
    return df
