import pandas as pd

def remove_blank_rows(df, activate):
    """
    Removes all rows that are entirely blank from the dataframe.
    
    Parameters:
    - df (DataFrame): The dataframe from which to remove blank rows.
    - activate (bool): A boolean to indicate whether to activate this manipulation.

    Returns:
    - DataFrame: The dataframe with blank rows removed if activated.
    """
    if activate:
        return df.dropna(how='all')
    return df

metadata = {
    'query': 'Remove blank rows? (y/n): ',
    'type': 'boolean',  # Ensure the type reflects the expected input format
    'function': remove_blank_rows  # Link the function directly to the metadata for easier access
}