import os
import importlib.util
import logging

logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

def load_manipulations():
    manipulations = {}
    directory = os.path.join(os.path.dirname(__file__))
    for filename in os.listdir(directory):
        if filename.endswith('.py') and filename != 'manipulation_core.py':
            module_name = filename[:-3]
            file_path = os.path.join(directory, filename)
            spec = importlib.util.spec_from_file_location(module_name, file_path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            if hasattr(module, 'metadata') and isinstance(module.metadata, dict) and callable(module.metadata.get('function')):
                manipulations[module_name] = module.metadata
                logging.debug(f"Loaded metadata for {module_name}: {module.metadata}")
            else:
                logging.error(f"Failed to load valid manipulation metadata for {module_name}. Check module setup.")
    return manipulations