import logging

# Configure logging at the module level, you might want to configure this at the application level instead.
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

def process_input(response, metadata, option):
    """
    Processes user input according to the type specified in the metadata for a given option.

    Parameters:
    - response (str): The raw input string from the user.
    - metadata (dict): A dictionary containing metadata about the input, including the expected type.
    - option (str): The name of the option being processed, used for error messages.

    Returns:
    - Various Types: Returns the processed input in the type specified by metadata, or None if there's a failure.

    Depending on the 'type' specified in metadata, this function processes the input and converts it:
    - 'boolean': Converts the input to True if the user enters 'y' or 'Y', otherwise False.
    - 'list': Splits the input string by commas into a list of strings.
    - 'integer': Attempts to convert the input to an integer, returning None and printing an error if it fails.
    - 'string': Returns the input as is.
    - 'dictionary': Attempts to parse a comma-separated key-value pair string into a dictionary.

    If the input does not meet the expected format, the function provides feedback to the user and may return None.
    """
    # Process the input based on the type specified in the metadata
    try:
        if metadata['type'] == 'boolean':
            result = response.lower() == 'y'
            logging.debug(f"Processed boolean input for {option}: {result}")
            return result
        elif metadata['type'] == 'list':
            result = response.split(',')
            logging.debug(f"Processed list input for {option}: {result}")
            return result
        elif metadata['type'] == 'integer':
            result = int(response)
            logging.debug(f"Processed integer input for {option}: {result}")
            return result
        elif metadata['type'] == 'string':
            logging.debug(f"Processed string input for {option}: {response}")
            return response
        elif metadata['type'] == 'dictionary':
            dict_entries = response.split(',')
            result = [(k.strip(), v.strip()) for k, v in (entry.split(':') for entry in dict_entries)]
            logging.debug(f"Processed dictionary input for {option}: {result}")
            return result
    except ValueError as e:
        logging.error(f"Invalid input for {option}. Error: {e}")
        return None
    except Exception as e:
        logging.error(f"Error processing input for {option}: {e}")
        return None