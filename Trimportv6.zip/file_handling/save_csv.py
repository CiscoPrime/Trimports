import pandas as pd

def save_csv(df, file_path, header=True):
    """
    Saves a pandas DataFrame to a CSV file at the specified location.

    Parameters:
    - df (DataFrame): The pandas DataFrame to be saved.
    - file_path (str): The path (including file name) where the CSV file will be saved.
    - index (bool): Determines whether to write row names (indices). Defaults to False.

    This function leverages pandas' to_csv method to write a DataFrame to a CSV file.
    By default, it does not save the DataFrame's index (row labels) to the file unless explicitly
    instructed to do so by setting 'index=True'. This can be useful for saving space or when the
    index does not contain meaningful data.

    Example usage:
    >>> df = pd.DataFrame({'A': [1, 2, 3], 'B': [4, 5, 6]})
    >>> save_csv(df, 'output.csv', index=True)  # This will include the index in the output file.
    """
    # Use DataFrame's to_csv method to save it as a CSV file; by default, the index is not saved
    df.to_csv(file_path, index=False, header=header)