import os
import json
from .utils import process_input
import logging

# Configure logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

def get_profiles():
    profiles_file = 'trim_profiles.json'
    try:
        if os.path.exists(profiles_file):
            with open(profiles_file, 'r') as file:
                profiles = json.load(file)
            logging.info("Profiles loaded successfully.")
        else:
            profiles = {}
            logging.info("No profiles found, starting with an empty dictionary.")
    except Exception as e:
        logging.error(f"Failed to load profiles from {profiles_file}: {e}")
        profiles = {}
    return profiles

def save_profiles(profiles):
    try:
        with open('trim_profiles.json', 'w') as file:
            json.dump(profiles, file, indent=4)
        logging.info("Profiles saved to 'trim_profiles.json'.")
    except Exception as e:
        logging.error(f"Failed to save profiles to 'trim_profiles.json': {e}")

def create_profile(manipulation_options):
    new_profile = {}
    logging.debug("Received manipulation options: " + str(manipulation_options))
    for option, details in manipulation_options.items():
        logging.debug(f"Processing {option}: {details}")
        if isinstance(details, dict):
            metadata = {key: val for key, val in details.items() if key != 'function'}
            response = input(metadata['query'])
            if response.strip():
                processed_input = process_input(response, details, option)
                if processed_input is not None:
                    new_profile[option] = processed_input
                    logging.info(f"Profile {option} created successfully.")
                else:
                    logging.warning(f"No valid input processed for {option}.")
            else:
                logging.warning(f"No input provided for {option}. Skipping this setting.")
        else:
            logging.error(f"Skipping {option} because the details are not a dictionary.")
    return new_profile