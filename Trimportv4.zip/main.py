import os
from file_handling.find_csv_files import find_csv_files
from file_handling.load_csv import load_csv
from file_handling.save_csv import save_csv
from profile_management.profile_operations import get_profiles, save_profiles, create_profile
from data_manipulation.manipulation_core import load_manipulation_modules

def main():
    # Initialize the working directory where CSV files are located.
    current_directory = os.getcwd()
    
    # Retrieve all CSV files within the working directory.
    csv_files = find_csv_files(current_directory)
    
    # Exit the program if no CSV files are found.
    if not csv_files:
        print("No CSV files found in the directory.")
        return

    # Display the available CSV files to the user.
    print("Available CSV files:")
    for index, file in enumerate(csv_files, 1):
        print(f"{index}. {file}")
    
    # Prompt user to select a CSV file by number.
    file_choice = int(input("Select a CSV file to trim (number): ")) - 1
    file_name = os.path.join(current_directory, csv_files[file_choice])

    # Load the selected CSV file into a DataFrame.
    df = load_csv(file_name)
    print("Original Data (first row treated as data):")
    print(df.head())

    # Load existing profiles or create a new one if none exist.
    profiles = get_profiles()
    manipulation_options = load_manipulation_modules()
    if not profiles:
        print("No profiles found, creating a new one.")
        profiles['Profile1'] = create_profile(manipulation_options)
        save_profiles(profiles)

    # User selects an existing profile or creates a new one for data manipulation.
    print("Select a trimming profile:")
    for i, key in enumerate(profiles.keys(), 1):
        print(f"{i}. {key}")
    print(f"{len(profiles) + 1}. Create a new trimming profile")

    choice = int(input("Enter your choice: "))
    if choice == len(profiles) + 1:
        profile_name = f"Profile{len(profiles) + 1}"
        profiles[profile_name] = create_profile(manipulation_options)
        save_profiles(profiles)
    else:
        profile_name = list(profiles.keys())[choice - 1]

    # Define a nested function to apply the selected profile to the DataFrame.
    def apply_profile(df, profile, manipulation_options):
        for key, value in profile.items():
            if value and key in manipulation_options:
                manipulation_function = manipulation_options[key]['function']
                df = manipulation_function(df, value)
        return df

    # Apply the chosen profile to the DataFrame and obtain the trimmed version.
    df_trimmed = apply_profile(df, profiles[profile_name], manipulation_options)

    # Optionally save the trimmed DataFrame back to a CSV file.
    if input("Save changes to new CSV file? (y/n): ") == 'y':
        save_path = f'trimmed_{os.path.basename(file_name)}'
        if profiles[profile_name].get("use_first_row_as_header", False):
            # Treat the first row as header if specified in the profile.
            header = df_trimmed.iloc[0]
            df_trimmed = df_trimmed[1:]
            save_csv(df_trimmed, save_path, header=header)
        else:
            save_csv(df_trimmed, save_path, header=False)
        print("Changes saved.")

if __name__ == "__main__":
    main()