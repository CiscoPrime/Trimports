import os
import importlib.util

def load_manipulation_modules():
    """
    Loads Python modules from the current directory that are meant for data manipulation.
    It skips 'manipulation_core.py' and only loads modules with a valid 'function' in their metadata.
    """
    manipulations = {}
    directory = os.path.join(os.path.dirname(__file__))  # Get the path of the current file's directory
    for filename in os.listdir(directory):  # Iterate through each file in the directory
        if filename.endswith('.py') and filename != 'manipulation_core.py':  # Ignore the core module
            module_name = filename[:-3]  # Remove the '.py' from the filename to get the module name
            file_path = os.path.join(directory, filename)  # Construct full file path
            spec = importlib.util.spec_from_file_location(module_name, file_path)  # Create a module spec
            module = importlib.util.module_from_spec(spec)  # Create a module from the spec
            spec.loader.exec_module(module)  # Load the module from its spec
            # Check if the module has a 'metadata' dictionary and a function defined within it
            if hasattr(module, 'metadata') and isinstance(module.metadata, dict) and 'function' in module.metadata:
                manipulations[module_name] = module.metadata # Add the function to the manipulations dict
            else:
                # Notify if the current module does not have a valid manipulation function
                print(f"No valid manipulation function in {module_name}. It may be the core or an incorrectly setup module.")
    return manipulations

def apply_manipulation(df, profile, manipulation_options):
    """
    Applies specified manipulations to a dataframe according to the provided profile.
    Only applies manipulations that are callable and specified in the profile's options.
    """
    for option, parameters in profile.items():  # Iterate through each option in the profile
        if option in manipulation_options:  # Check if the option is a valid manipulation option
            manipulation_function = manipulation_options[option]  # Retrieve the manipulation function
            if callable(manipulation_function):  # Check if the function is callable
                df = manipulation_function(df, parameters)  # Apply the manipulation to the dataframe
            else:
                # If the function is not callable, notify the user
                print(f"No valid function callable for {option}. Check metadata definition.")
    return df  # Return the manipulated dataframe