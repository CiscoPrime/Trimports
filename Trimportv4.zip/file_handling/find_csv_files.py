import os
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)

def find_csv_files(directory):
    """
    This function scans a given directory and returns a list of all files ending with '.csv'.

    Parameters:
    - directory (str): The path to the directory where the search is performed.

    Returns:
    - list: A list containing the names of all the '.csv' files found in the specified directory.

    The function uses os.listdir to iterate over every file in the specified directory.
    It then filters these files, including only those that end with the '.csv' extension.
    This is done using a list comprehension, which checks the suffix of each file name.
    """
    try:
        # Use list comprehension to filter for CSV files
        csv_files = [f for f in os.listdir(directory) if f.endswith('.csv')]
        logging.info(f"Found {len(csv_files)} CSV files in {directory}")
        return csv_files
    except OSError as e:
        logging.error(f"Error while searching for CSV files in {directory}: {e}")
        return []

# Example usage:
# csv_files = find_csv_files('/path/to/directory')
# print(csv_files)