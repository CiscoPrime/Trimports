import os  # Import the os module for interacting with the operating system.
from file_handling.find_csv_files import find_csv_files  # Import the function to find CSV files from a specific directory.
from file_handling.load_csv import load_csv  # Import the function to load CSV files into a DataFrame.
from file_handling.save_csv import save_csv  # Import the function to save DataFrames to CSV files.
from profile_management.profile_operations import get_profiles, save_profiles, create_profile  # Import functions for managing manipulation profiles.
from data_manipulation.manipulation_core import load_manipulation_modules  # Import a function to load data manipulation modules.

def main():  # Define the main function where the script starts executing.
    current_directory = os.getcwd()  # Get the current working directory.
    
    csv_files = find_csv_files(current_directory)  # Find all CSV files in the current directory.
    
    if not csv_files:  # Check if any CSV files were found.
        print("No CSV files found in the directory.")  # Inform the user if no CSV files are found.
        return  # Exit the function early if no CSV files are present.
    
    print("Available CSV files:")  # Print a header for the list of available CSV files.
    for index, file in enumerate(csv_files, 1):  # Iterate through the list of CSV files, displaying them to the user with a number.
        print(f"{index}. {file}")  # Display each CSV file with its corresponding index.
    
    file_choice = int(input("Select a CSV file to trim (number): ")) - 1  # Ask the user to select a CSV file by number.
    file_name = os.path.join(current_directory, csv_files[file_choice])  # Build the full path to the chosen CSV file.
    
    df = load_csv(file_name)  # Load the chosen CSV file into a DataFrame.
    print("Original Data (first row treated as data):")  # Display a message about how data will be shown.
    print(df.head())  # Show the first few rows of the DataFrame to give the user an overview.
    
    profiles = get_profiles()  # Load manipulation profiles or create an empty dictionary if none exist.
    manipulation_options = load_manipulation_modules()  # Load available manipulation options.
    if not profiles:  # Check if any profiles were loaded.
        print("No profiles found, creating a new one.")  # Inform the user that no profiles were found and a new one will be created.
        profiles['Profile1'] = create_profile(manipulation_options)  # Create a new profile with default options.
        save_profiles(profiles)  # Save the newly created profile.
    
    print("Select a trimming profile:")  # Prompt the user to select a trimming profile.
    for i, key in enumerate(profiles.keys(), 1):  # Iterate over the profile keys, displaying them with a number.
        print(f"{i}. {key}")  # Print each profile name with its number.
    print(f"{len(profiles) + 1}. Create a new trimming profile")  # Give an option to create a new profile.
    
    choice = int(input("Enter your choice: "))  # Get the user's choice for which profile to use or to create a new one.
    if choice == len(profiles) + 1:  # Check if the user chose to create a new profile.
        profile_name = f"Profile{len(profiles) + 1}"  # Assign a name to the new profile.
        profiles[profile_name] = create_profile(manipulation_options)  # Create a new profile using the manipulation options.
        save_profiles(profiles)  # Save the updated profiles.
    else:
        profile_name = list(profiles.keys())[choice - 1]  # Get the name of the chosen profile.
    
    def apply_profile(df, profile, manipulation_options):  # Define a function to apply the selected profile to a DataFrame.
        for key, value in profile.items():  # Iterate over the key-value pairs in the profile.
            if value and key in manipulation_options:  # Check if the profile setting is enabled and exists in the options.
                manipulation_function = manipulation_options[key]['function']  # Get the corresponding manipulation function.
                df = manipulation_function(df, value)  # Apply the function to the DataFrame.
        return df  # Return the modified DataFrame.
    
    df_trimmed = apply_profile(df, profiles[profile_name], manipulation_options)  # Apply the profile to the DataFrame and get the trimmed version.
    
    if input("Save changes to new CSV file? (y/n): ") == 'y':  # Ask the user if they want to save the changes to a new file.
        save_path = f'trimmed_{os.path.basename(file_name)}'  # Construct a path for the new CSV file.
        if profiles[profile_name].get("use_first_row_as_header", False):  # Check if the first row should be used as a header.
            header = df_trimmed.iloc[0]  # Set the first row as the header.
            df_trimmed = df_trimmed[1:]  # Remove the first row from the DataFrame.
            save_csv(df_trimmed, save_path, header=header)  # Save the DataFrame to a CSV file using the header.
        else:
            save_csv(df_trimmed, save_path, header=False)  # Save the DataFrame to a CSV file without a header.
        print("Changes saved.")  # Inform the user that the changes have been saved.

if __name__ == "__main__":  # Check if the script is run as the main program.
    main()  # Call the main function.