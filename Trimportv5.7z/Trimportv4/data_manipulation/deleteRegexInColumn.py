import pandas as pd
import re

def manipulation(df, data_to_remove):
    """
    Deletes specified patterns from specified columns using regular expressions.

    Parameters:
    - df (DataFrame): The dataframe from which to delete data.
    - data_to_remove (list of tuples): Each tuple contains column name and regex pattern to be deleted.

    Returns:
    - DataFrame: The dataframe with specified patterns removed.
    """
    for col, patterns in data_to_remove: #iterate through pairs
        df[col] = df[col].apply(lambda x: re.sub(patterns, '', str(x))) #use re.sub() to replace pattern with ''
    return df

metadata = {
    'query': 'Enter comma separated list of pairs identifying Column:RegEx to be deleted e.g. APName:< will match any < in APName column: ',
    'type': 'dictionary',
    'function': manipulation
}