import pandas as pd
import logging

# Setup basic configuration for logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Define metadata for manipulation function, specifying the type of user input expected
metadata = {
    'query': 'Trim prefixes from first column? Enter prefixes separated by commas: ',
    'type': 'list',
}

def manipulation(df, prefixes):
    """
    Trims rows from the dataframe where the first column starts with any of the specified prefixes.
    
    Parameters:
    - df (DataFrame): The dataframe to manipulate.
    - prefixes (list): A list of string prefixes to remove from the first column.

    Returns:
    - DataFrame: The manipulated dataframe with specified prefixes removed from the first column.
    """

    # Calculate the initial number of rows in the dataframe for later comparison
    original_count = len(df)
    logging.info(f"Original row count: {original_count}")

    # Generate conditions for each prefix; checks if any cell in the first column starts with the prefix
    conditions = [df.iloc[:, 0].fillna('UNLIKELY_PREFIX').str.contains(f"^{prefix}", regex=True) for prefix in prefixes]
    logging.debug(f"Prefix conditions set up for: {prefixes}")

    # Filter the dataframe to exclude rows that match any prefix conditions
    df = df[~pd.concat(conditions, axis=1).any(axis=1)]

    # Verification Step: Ensure no rows still start with the specified prefixes (additional safety)
    remaining_conditions = [df.iloc[:, 0].fillna('UNLIKELY_PREFIX').str.startswith(prefix) for prefix in prefixes]
    if pd.concat(remaining_conditions, axis=1).any().any():
        logging.error("Error: Not all specified prefixes were removed successfully.")
        # Ensure removal of any rows that still start with any prefix
        df = df[~pd.concat(remaining_conditions, axis=1).any(axis=1)]

    # Report the number of rows removed as a result of the manipulation
    logging.info(f"Successfully removed {original_count - len(df)} rows.")
    return df

# Link the manipulation function to 'function' key in the metadata dictionary for easy access
metadata['function'] = manipulation