import pandas as pd
import logging

# Setup basic configuration for logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


def manipulation(df, identifiers):
    """
    Deletes specified columns from the dataframe based on column names or indices provided by the user.

    Parameters:
    - df (DataFrame): The dataframe from which to delete columns.
    - identifiers (str): A string containing column names or indices separated by commas.

    Returns:
    - DataFrame: The dataframe with specified columns removed.
    """
    columns_to_drop = []
    for identifier in identifiers.split(','):
        identifier = identifier.strip()
        try:
            # If identifier is an index
            col_index = int(identifier) - 1
            if 0 <= col_index < len(df.columns):
                columns_to_drop.append(df.columns[col_index])
            else:
                logging.warning(f"Index {col_index+1} is out of range and will be ignored.")
        except ValueError:
            # If identifier is a column name
            if identifier in df.columns:
                columns_to_drop.append(identifier)
            else:
                logging.warning(f"Column '{identifier}' not found in DataFrame.")

    if columns_to_drop:
        df = df.drop(columns=columns_to_drop)
        logging.info(f"Columns {columns_to_drop} deleted successfully.")
    else:
        logging.info("No valid column identifiers provided. No columns deleted.")

    return df

metadata = {
    'query': 'Delete specific columns by name or index? (Enter column identifiers separated by commas): ',
    'type': 'string',
    'function': manipulation
}