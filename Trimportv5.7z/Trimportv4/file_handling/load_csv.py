import pandas as pd

def load_csv(file_name):
    """
    Loads a CSV file into a pandas DataFrame.

    Parameters:
    - file_name (str): The full path to the CSV file to be loaded.

    Returns:
    - DataFrame: A DataFrame containing the data read from the CSV file.

    The function uses pandas' read_csv method, which automatically assumes the first row of the CSV
    file to be the header unless specified otherwise. This method also handles different encoding
    formats and delimiters gracefully but might require additional parameters for non-standard CSV files.

    For example, if a CSV file has no header, the function should be modified to call:
    pd.read_csv(file_name, header=None)
    Or, to specify a delimiter other than a comma, you might use:
    pd.read_csv(file_name, delimiter=';')
    """
    # Load the CSV file into a DataFrame with pandas' default settings (assuming header in first row)
    return pd.read_csv(file_name)
